
<?php get_header()?>
  <div id="page" class="site">
    <main id="main" class="site-main text-center">
    <div class="flex justify-end  max-w-screen-lg mx-auto pt-12 gap-3 text-xs font-medium">
            <a href="#" 
            class="py-2 px-4 border border-blue-700 border-1  rounded-full hover:bg-blue-700 hover:text-white 
            hover:transition-all duration-300 ease-in-out">هدست</a>
    
            <a href="#" 
            class="py-2 px-4 border border-blue-700 border-1  rounded-full hover:bg-blue-700 hover:text-white 
            hover:transition-all duration-300 ease-in-out">وسایل گیمینگ</a>
     
            <a href="#" 
            class="py-2 px-4 border border-blue-700 border-1  rounded-full hover:bg-blue-700 hover:text-white 
            hover:transition-all duration-300 ease-in-out">هدفون</a>
     
            <a href="#" 
            class="py-2 px-4 border border-blue-700 border-1  rounded-full hover:bg-blue-700 hover:text-white 
            hover:transition-all duration-300 ease-in-out">کنسول بازی</a>
     
            <a href="#" 
            class="py-2 px-4 border border-blue-700 border-1  rounded-full hover:bg-blue-700 hover:text-white 
            hover:transition-all duration-300 ease-in-out">دوربین</a>
     
            <a href="#" 
            class="py-2 px-4 border border-blue-700 border-1  rounded-full hover:bg-blue-700 hover:text-white 
            hover:transition-all duration-300 ease-in-out">همه محصولات </a>
        </div>
   
        <div class="flex grid-cols-1 md:grid-cols-4 gap-4 mt-6 justify-center">
        <div class=" shadow-sm rounded-lg text-right juctify-right">
                <img src="<?php echo get_template_directory_uri();?>/picture/cameraAX6062.png" alt="cameraAX6062" class="w-75 h-55 rounded-lg">
               <p class="text-sm font-bold py-3 pr-2"> AX6062 دوربین دیجیتال آکسون مدل</p>
               <p class="text-xs pr-2 text-gray-700">دوربین</p>
               <!-- ******** -->
               <div class="flex pr-3 pt-4 max-w-screen-lg mx-auto ">
               <span class="flex items-center text-left justify-center text-xs px-3 text-gray-400 ">تومان</span>
               <span class="flex items-center justify-center text-base pr-28">27,399,000</span> 
               <div class=" flex items-center justify-center w-9 h-7 bg-red-700 text-white rounded-lg text-xs">
               <span class="">4%</span>
                </div>
             
                </div>
                <div class="mt-auto py-4">
                  <div class="flex flex-row-reverse gap-2 mt-3 justify-center">
                  <button class="text-white text-xs py-4 px-6 bg-blue-900 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                      افزودن  به سبد خرید 
                  </button>
                  <button class="text-white text-xs py-4 px-6 bg-gray-700 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                    نمایش جزئیات
                  </button>
                
                    </div>
               </div>
            
           
        </div>
        <!-- ******************* -->
        <div class=" shadow-sm rounded-lg text-right juctify-right">
                <img src="<?php echo get_template_directory_uri();?>/picture/cameraAX6062.png" alt="cameraAX6062" class="w-75 h-55 rounded-lg">
               <p class="text-sm font-bold py-3 pr-2"> AX6062 دوربین دیجیتال آکسون مدل</p>
               <p class="text-xs pr-2 text-gray-700">دوربین</p>
               <!-- ******** -->
               <div class="flex pr-3 pt-4 max-w-screen-lg mx-auto ">
               <span class="flex items-center text-left justify-center text-xs px-3 text-gray-400 ">تومان</span>
               <span class="flex items-center justify-center text-base pr-28">27,399,000</span> 
               <div class=" flex items-center justify-center w-9 h-7 bg-red-700 text-white rounded-lg text-xs">
               <span class="">4%</span>
                </div>
             
                </div>
                <div class="mt-auto py-4">
                  <div class="flex flex-row-reverse gap-2 mt-3 justify-center">
                  <button class="text-white text-xs py-4 px-6 bg-blue-900 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                      افزودن  به سبد خرید 
                  </button>
                  <button class="text-white text-xs py-4 px-6 bg-gray-700 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                    نمایش جزئیات
                  </button>
                
                    </div>
               </div>
            
         
        </div>
        <!-- ***************** -->
            <div class=" shadow-sm rounded-lg text-right juctify-right">
                <img src="<?php echo get_template_directory_uri();?>/picture/cameraAX6062.png" alt="cameraAX6062" class="w-75 h-55 rounded-lg">
               <p class="text-sm font-bold py-3 pr-2"> AX6062 دوربین دیجیتال آکسون مدل</p>
               <p class="text-xs pr-2 text-gray-700">دوربین</p>
               <!-- ******** -->
               <div class="flex pr-3 pt-4 max-w-screen-lg mx-auto ">
               <span class="flex items-center text-left justify-center text-xs px-3 text-gray-400 ">تومان</span>
               <span class="flex items-center justify-center text-base pr-28">27,399,000</span> 
               <div class=" flex items-center justify-center w-9 h-7 bg-red-700 text-white rounded-lg text-xs">
               <span class="">4%</span>
                </div>
             
                </div>
                <div class="mt-auto py-4">
                  <div class="flex flex-row-reverse gap-2 mt-3 justify-center">
                  <button class="text-white text-xs py-4 px-6 bg-blue-900 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                      افزودن  به سبد خرید 
                  </button>
                  <button class="text-white text-xs py-4 px-6 bg-gray-700 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                    نمایش جزئیات
                  </button>
                
                    </div>
               </div>
            
            </div>
        </div>
      <!-- ****************** -->
       
      <div class="flex grid-cols-1 md:grid-cols-4 gap-4 mt-6 justify-center">
      <div class=" shadow-sm rounded-lg text-right juctify-right">
                <img src="<?php echo get_template_directory_uri();?>/picture/cameraAX6062.png" alt="cameraAX6062" class="w-75 h-55 rounded-lg">
               <p class="text-sm font-bold py-3 pr-2"> AX6062 دوربین دیجیتال آکسون مدل</p>
               <p class="text-xs pr-2 text-gray-700">دوربین</p>
               <!-- ******** -->
               <div class="flex pr-3 pt-4 max-w-screen-lg mx-auto ">
               <span class="flex items-center text-left justify-center text-xs px-3 text-gray-400 ">تومان</span>
               <span class="flex items-center justify-center text-base pr-28">27,399,000</span> 
               <div class=" flex items-center justify-center w-9 h-7 bg-red-700 text-white rounded-lg text-xs">
               <span class="">4%</span>
                </div>
             
                </div>
                <div class="mt-auto py-4">
                  <div class="flex flex-row-reverse gap-2 mt-3 justify-center">
                  <button class="text-white text-xs py-4 px-6 bg-blue-900 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                      افزودن  به سبد خرید 
                  </button>
                  <button class="text-white text-xs py-4 px-6 bg-gray-700 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                    نمایش جزئیات
                  </button>
                
                    </div>
               </div>
            
         
        </div>
        <!-- ****************** -->
        <div class=" shadow-sm rounded-lg text-right juctify-right">
                <img src="<?php echo get_template_directory_uri();?>/picture/cameraAX6062.png" alt="cameraAX6062" class="w-75 h-55 rounded-lg">
               <p class="text-sm font-bold py-3 pr-2"> AX6062 دوربین دیجیتال آکسون مدل</p>
               <p class="text-xs pr-2 text-gray-700">دوربین</p>
               <!-- ******** -->
               <div class="flex pr-3 pt-4 max-w-screen-lg mx-auto ">
               <span class="flex items-center text-left justify-center text-xs px-3 text-gray-400 ">تومان</span>
               <span class="flex items-center justify-center text-base pr-28">27,399,000</span> 
               <div class=" flex items-center justify-center w-9 h-7 bg-red-700 text-white rounded-lg text-xs">
               <span class="">4%</span>
                </div>
             
                </div>
                <div class="mt-auto py-4">
                  <div class="flex flex-row-reverse gap-2 mt-3 justify-center">
                  <button class="text-white text-xs py-4 px-6 bg-blue-900 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                      افزودن  به سبد خرید 
                  </button>
                  <button class="text-white text-xs py-4 px-6 bg-gray-700 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                    نمایش جزئیات
                  </button>
                
                    </div>
               </div>
            
           
        </div>
        <!-- *************** -->
           <div class=" shadow-sm rounded-lg text-right juctify-right">
                <img src="<?php echo get_template_directory_uri();?>/picture/cameraAX6062.png" alt="cameraAX6062" class="w-75 h-55 rounded-lg">
               <p class="text-sm font-bold py-3 pr-2"> AX6062 دوربین دیجیتال آکسون مدل</p>
               <p class="text-xs pr-2 text-gray-700">دوربین</p>
               <!-- ******** -->
               <div class="flex pr-3 pt-4 max-w-screen-lg mx-auto ">
               <span class="flex items-center text-left justify-center text-xs px-3 text-gray-400 ">تومان</span>
               <span class="flex items-center justify-center text-base pr-28">27,399,000</span> 
               <div class=" flex items-center justify-center w-9 h-7 bg-red-700 text-white rounded-lg text-xs">
               <span class="">4%</span>
                </div>
             
                </div>
                <div class="mt-auto py-4">
                  <div class="flex flex-row-reverse gap-2 mt-3 justify-center">
                  <button class="text-white text-xs py-4 px-6 bg-blue-900 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                      افزودن  به سبد خرید 
                  </button>
                  <button class="text-white text-xs py-4 px-6 bg-gray-700 opacity-90 text-white py-2 px-4 rounded-xl hover:opacity-100 hover:transition-all duration-300 ease-in-out">
                    نمایش جزئیات
                  </button>
                
                    </div>
               </div>
            
            </div>
        </div>
    </div>
        <!-- ********* -->
        <div class="flex justify-center pt-8 gap-2">
        <div class="py-2 px-4 border-1  border-blue-300 rounded-sm">بعدی</div>
          <div class="py-2 px-4  bg-blue-300 rounded-sm">1</div>
          <div class="py-2 px-4 border-1 border-blue-300 rounded-sm">2</div>
          <div class="py-2 px-4 border-1 border-blue-300 rounded-sm">قبلی</div>
        </div>
      <?php
      if ( have_posts() ) {
        while ( have_posts() ) {
          the_post();
          the_title( '<h2>', '</h2>' );
          the_content();
        }
      } else {
        echo '<p>No content found.</p>';
      }
      ?>
    </main>
  </div>
  <?php get_footer()?>

  

