
<footer class="bg-white shadow-top-sm text-center">

    <div class="flex item-center px-3">

    <div class="flex items-center justify-start  max-w-screen-lg mx-auto ">
        <div class=" flex gap-2">
    <div class="border-1 border-gray-500 rounded-full p-2">
    <img src="<?php echo get_template_directory_uri();?>/HodeCode 2 - logo - shadowed.png" alt="hodecodelogo" class="w-5 h-5">
    </div>
    <div class="border-1 border-gray-500 rounded-full p-2">
    <img src="<?php echo get_template_directory_uri();?>/HodeCode 2 - logo - shadowed.png" alt="hodecodelogo" class="w-5 h-5">
    </div>
    <div class="border-1 border-gray-500 rounded-full p-2">
    <img src="<?php echo get_template_directory_uri();?>/HodeCode 2 - logo - shadowed.png" alt="hodecodelogo" class="w-5 h-5">
    </div>
    </div>
    </div>
    <div class="flex items-center justify-center text-center  max-w-screen-lg mx-auto">
        <div class="flex text-center justify-center">
      <span class="text-sm  justify-center font-bold pr-95">
        کلیه حقوق این سایت برای پارت محفوظ می‌باشد
      </span>
      </div>
        <img src="<?php echo get_template_directory_uri();?>/HodeCode 2 - logo - shadowed.png" alt="hodecodelogo" class="w-15 h-15">
    </div>
   

</div> 





</footer>




<?php wp_footer(); ?>
</body>
</html>
 