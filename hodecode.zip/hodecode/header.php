<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
  <link rel="profile" href="https://gmpg.org/xfn/11">
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/fonts.css" rel="stylesheet">
   <link rel="stylesheet" href="style.css">
  <?php wp_head(); ?>
</head>

<body <?php body_class("bg-white-100"); ?>>
<header class="bg-white shadow-sm">
    <div class="flex item-center ">
    <div class="flex items-center justify-start  max-w-screen-lg mx-auto">
        <img src="<?php echo get_template_directory_uri();?>/shoppingcart.png" alt="shopping-cart" class="w-9 h-9">
        <ul>
            <li class="inline-block p-4">ارتباط با ما</li>
        </ul>
    </div>
    <div class="flex items-center justify-end  max-w-screen-lg mx-auto">
        <ul>
            <li class="inline-block px-2">خانه</li>
            <li class="inline-block px-2">محصولات</li>
        </ul>
        <img src="<?php echo get_template_directory_uri();?>/HodeCode 2 - logo - shadowed.png" alt="hodecodelogo" class="w-15 h-15">
    </div>
</div> 
</header>